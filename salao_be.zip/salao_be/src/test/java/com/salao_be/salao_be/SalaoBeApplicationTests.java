package com.salao_be.salao_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalaoBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
